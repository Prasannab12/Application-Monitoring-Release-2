#!/bin/sh
export APP_HOME=/home/sagacity/Testing/AppMonitoring
export APP_PROP_PATH=${APP_HOME}/config
cd ${APP_HOME}
java -jar AppMonitoring.jar
